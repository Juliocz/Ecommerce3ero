@extends('layouts.home')
@section('contenido')
@include('landing.info_banderas')
@endsection
