<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="<?php echo e(asset('landingres/BANNER1.png')); ?>" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="<?php echo e(asset('landingres/BANNER2.png')); ?>" class="d-block w-100" alt="...">
      </div>
      <div class="carousel-item">
        <img src="<?php echo e(asset('landingres/BANNER3.png')); ?>" class="d-block w-100" alt="...">
      </div>

      <div style="position: absolute;width: 100%;"></div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true" style="background-color: black;"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">

     <span class="carousel-control-next-icon" aria-hidden="true" style="background-color: black;"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
<?php /**PATH E:\Users\Julio\Documents\LaravelProjects\ecomerce3ero\Ecommerce3ero\laravel\resources\views/landing/carrosel.blade.php ENDPATH**/ ?>