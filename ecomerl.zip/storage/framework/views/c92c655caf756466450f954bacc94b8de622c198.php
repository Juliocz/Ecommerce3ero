<?php $__env->startSection('contenido'); ?>
<?php echo $__env->make('landing.info_banderas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Users\Julio\Documents\LaravelProjects\ecomerce3ero\Ecommerce3ero\laravel\resources\views/landing/landing.blade.php ENDPATH**/ ?>