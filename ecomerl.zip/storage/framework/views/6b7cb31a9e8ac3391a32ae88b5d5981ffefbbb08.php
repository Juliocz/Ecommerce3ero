<?php $__env->startSection('body'); ?>
    <?php echo $__env->make('usuario.modal_register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('usuario.modal_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div style="position: fixed;width: 100%;z-index: 1;"><?php echo $__env->make('layouts.navbarhome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
   <div style="width: 100%;visibility: hidden;"><?php echo $__env->make('layouts.navbarhome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>

    <?php echo $__env->make('landing.carrosel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('contenido'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Users\Julio\Documents\LaravelProjects\ecomerce3ero\Ecommerce3ero\laravel\resources\views/layouts/home.blade.php ENDPATH**/ ?>